package com.example.dhproject2;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class DashboardActivity extends BaseActivity {

    private TextView currentWeightDisplay, goalWeightDisplay, weightToGoDisplay;
    private Button updateTodaysWeightButton;
    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_screen);

        currentWeightDisplay = findViewById(R.id.curerntWeightDisplay);
        goalWeightDisplay = findViewById(R.id.goalWeightDisplay);
        weightToGoDisplay = findViewById(R.id.weightToGoDisplay);
        updateTodaysWeightButton = findViewById(R.id.updateTodaysWeightButton);

        dbHelper = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        username = prefs.getString("username", "defaultUser");

        updateTodaysWeightButton.setOnClickListener(v ->
                startActivity(new android.content.Intent(DashboardActivity.this, WeightTrackingActivity.class))
        );

        loadDashboardWeights();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardWeights(); // Refresh data when returning
    }

    private void loadDashboardWeights() {
        double latestWeight = dbHelper.getLatestWeight(username);

        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        String goalWeightStr = prefs.getString("goalWeight", "180");
        int goalWeight = Integer.parseInt(goalWeightStr);

        currentWeightDisplay.setText(latestWeight + " LB");
        goalWeightDisplay.setText(goalWeight + " LB");
        weightToGoDisplay.setText((int)(latestWeight - goalWeight) + " LB to go!!");
    }
}
