package com.example.dhproject2;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;

public class BaseActivity extends androidx.appcompat.app.AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.home) {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            return true;
        } else if (id == R.id.weightTracking) {
            startActivity(new Intent(this, WeightTrackingActivity.class));
            return true;
        } else if (id == R.id.goals) {
            startActivity(new Intent(this, GoalsActivity.class));
            return true;
        } else if (id == R.id.smsnotification) {
            startActivity(new Intent(this, SmsActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}