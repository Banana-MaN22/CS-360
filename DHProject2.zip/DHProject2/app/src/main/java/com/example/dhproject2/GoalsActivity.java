package com.example.dhproject2;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GoalsActivity extends BaseActivity {

    private EditText editTextCurrentWeight, editTextGoalWeight;
    private Button buttonSaveGoals;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goals_screen);

        editTextCurrentWeight = findViewById(R.id.editTextCurrentWeight);
        editTextGoalWeight = findViewById(R.id.editTextGoalWeight);
        buttonSaveGoals = findViewById(R.id.buttonSaveGoals);

        sharedPreferences = getSharedPreferences("WeightPrefs", MODE_PRIVATE);

        // Load saved values if they exist
        editTextCurrentWeight.setText(sharedPreferences.getString("currentWeight", ""));
        editTextGoalWeight.setText(sharedPreferences.getString("goalWeight", ""));

        buttonSaveGoals.setOnClickListener(v -> {
            String currentWeight = editTextCurrentWeight.getText().toString();
            String goalWeight = editTextGoalWeight.getText().toString();

            if (!currentWeight.isEmpty() && !goalWeight.isEmpty()) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("currentWeight", currentWeight); // Optional: update current weight
                editor.putString("goalWeight", goalWeight);
                editor.apply();

                Toast.makeText(this, "Goals Saved", Toast.LENGTH_SHORT).show();

                // Finish the activity so that Dashboard resumes and updates
                finish();
            } else {
                Toast.makeText(this, "Please enter both weights", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
