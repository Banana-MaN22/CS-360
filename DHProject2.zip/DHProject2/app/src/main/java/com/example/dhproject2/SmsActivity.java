package com.example.dhproject2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

public class SmsActivity extends BaseActivity {

    private TextView textSMSPermissionStatus;
    private Button buttonRequestPermission;

    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_screen);

        textSMSPermissionStatus = findViewById(R.id.textSMSPermissionStatus);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);

        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        textSMSPermissionStatus.setText("SMS Permission granted");
                    } else {
                        textSMSPermissionStatus.setText("SMS Permission denied");
                    }
                });

        updatePermissionStatus();

        buttonRequestPermission.setOnClickListener(v -> requestPermission());
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            textSMSPermissionStatus.setText("SMS Permission granted");
        } else {
            textSMSPermissionStatus.setText("SMS Permission not granted");
        }
    }

    private void requestPermission() {
        requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }
}