package com.example.dhproject2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button signInButton, newUserButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        signInButton = findViewById(R.id.signInButton);
        newUserButton = findViewById(R.id.newUserButton);

        signInButton.setOnClickListener(v -> handleLogin());
        newUserButton.setOnClickListener(v -> handleLogin());
    }

    private void handleLogin() {
        String username = usernameEditText.getText().toString().trim();
        if (username.isEmpty()) {
            usernameEditText.setError("Enter a username");
            return;
        }

        // Save username in SharedPreferences
        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        prefs.edit().putString("username", username).apply();

        // Launch dashboard
        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
        finish();
    }
}