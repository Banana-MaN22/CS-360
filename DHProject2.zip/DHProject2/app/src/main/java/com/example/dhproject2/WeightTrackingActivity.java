package com.example.dhproject2;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;

public class WeightTrackingActivity extends BaseActivity {

    private TableLayout tableWeightData;
    private EditText editTextDate, editTextWeight;
    private Button buttonAddEntry;

    private DatabaseHelper dbHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_tracking);

        tableWeightData = findViewById(R.id.tableWeightData);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonAddEntry = findViewById(R.id.buttonAddEntry);

        dbHelper = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        username = prefs.getString("username", "defaultUser");

        loadWeightsFromDatabase();

        buttonAddEntry.setOnClickListener(v -> {
            String date = editTextDate.getText().toString();
            String weightStr = editTextWeight.getText().toString();

            if (!date.isEmpty() && !weightStr.isEmpty()) {
                double weight = Double.parseDouble(weightStr);

                if (dbHelper.insertWeight(username, date, weight)) {
                    editTextDate.setText("");
                    editTextWeight.setText("");
                    loadWeightsFromDatabase(); // Refresh table
                }
            }
        });
    }

    private void loadWeightsFromDatabase() {
        tableWeightData.removeViews(1, Math.max(0, tableWeightData.getChildCount() - 1));

        Cursor cursor = dbHelper.getUserWeights(username);
        if (cursor != null && cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_DATE));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT));

                TableRow row = new TableRow(this);

                TextView tvDate = new TextView(this);
                tvDate.setText(date);
                row.addView(tvDate);

                TextView tvWeight = new TextView(this);
                tvWeight.setText(weight + " lbs");
                row.addView(tvWeight);

                TextView tvChange = new TextView(this);
                tvChange.setText("-");
                row.addView(tvChange);

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");
                deleteButton.setOnClickListener(v -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Delete Entry")
                            .setMessage("Are you sure you want to delete this weight entry?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                dbHelper.deleteWeight(id);
                                loadWeightsFromDatabase();
                            })
                            .setNegativeButton("No", null)
                            .show();
                });
                row.addView(deleteButton);

                tableWeightData.addView(row);
                cursor.moveToNext();
            }
            cursor.close();
        }
    }
}

