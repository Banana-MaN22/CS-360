package com.example.dhproject2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Info
    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 2; // increment version if table structure changes

    // Table: Weights
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_ID = "id";
    public static final String COL_USERNAME = "username"; // New column for per-user tracking
    public static final String COL_DATE = "date";
    public static final String COL_WEIGHT = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_DATE + " TEXT, " +
                COL_WEIGHT + " REAL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old table and recreate if schema changes
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // Insert weight for a user
    public boolean insertWeight(String username, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_DATE, date);
        cv.put(COL_WEIGHT, weight);
        long result = db.insert(TABLE_WEIGHTS, null, cv);
        return result != -1;
    }

    // Get all weights for a user
    public Cursor getUserWeights(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTS + " WHERE " + COL_USERNAME + "=? ORDER BY " + COL_ID + " ASC",
                new String[]{username});
    }

    // Get the most recent weight for a user
    public double getLatestWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        double latestWeight = 0;
        Cursor cursor = db.rawQuery("SELECT " + COL_WEIGHT + " FROM " + TABLE_WEIGHTS +
                " WHERE " + COL_USERNAME + "=? ORDER BY " + COL_ID + " DESC LIMIT 1", new String[]{username});
        if (cursor.moveToFirst()) {
            latestWeight = cursor.getDouble(0);
        }
        cursor.close();
        return latestWeight;
    }

    // Delete a specific weight entry by ID
    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHTS, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete all weights for a specific user
    public void deleteAllWeightsForUser(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHTS, COL_USERNAME + "=?", new String[]{username});
    }
}